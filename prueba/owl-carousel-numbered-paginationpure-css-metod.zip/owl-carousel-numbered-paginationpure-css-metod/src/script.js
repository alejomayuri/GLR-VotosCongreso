$(".owl-carousel").owlCarousel({
  margin:10,
  loop:true,
  dots: true,
  nav: true,
  items: 1
});    