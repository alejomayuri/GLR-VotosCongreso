# Owl carousel numbered pagination - pure css metod

A Pen created on CodePen.io. Original URL: [https://codepen.io/jovanivezic/pen/JXWOex](https://codepen.io/jovanivezic/pen/JXWOex).

